import Foundation
import Combine

@MainActor
class SerialPortMonitor: ObservableObject {
    @Published var selectedDevice: String? = nil
    @Published var availableDevices: [String] = []

    var deviceFound: Bool {
        selectedDevice != nil
    }

    private var timer: Timer?

    init() {
        startMonitoring()
    }

    func startMonitoring() {
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            Task { @MainActor in
                let ports = listAllSerialPorts()
                self.availableDevices = ports
                if self.selectedDevice == nil || !ports.contains(self.selectedDevice!) {
                    self.selectedDevice = ports.first
                }
            }
        }
    }

    func stopMonitoring() {
        timer?.invalidate()
        timer = nil
    }
}

func findUSBDevice() -> String? {
    let task = Process()
    task.executableURL = URL(fileURLWithPath: "/bin/zsh")
    task.arguments = ["-c", "ls /dev/cu.* | grep -E 'usbserial|wchusbserial|cp210|usbmodem|ch34' | head -n1"]

    let pipe = Pipe()
    task.standardOutput = pipe

    do {
        try task.run()
        task.waitUntilExit()

        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let output = String(decoding: data, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
        return output.isEmpty ? nil : output
    } catch {
        return nil
    }
}

func listAllSerialPorts() -> [String] {
    let task = Process()
    task.executableURL = URL(fileURLWithPath: "/bin/zsh")
    task.arguments = ["-c", "ls /dev/cu.* | grep -E 'usbserial|wchusbserial|cp210|usbmodem|ch34'"]

    let pipe = Pipe()
    task.standardOutput = pipe

    do {
        try task.run()
        task.waitUntilExit()
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let output = String(decoding: data, as: UTF8.self)
        return output.split(separator: "\n").map { String($0) }
    } catch {
        return []
    }
}
