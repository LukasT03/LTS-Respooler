import Foundation

private actor DataAccumulator {
    private var data = Data()
    func append(_ d: Data) { data.append(d) }
    func snapshot() -> Data { data }
}

enum ESP32Flasher {
    static func flash(binPath: String, port: String) async -> Bool {
        guard let tool = Bundle.main.resourceURL?.appendingPathComponent("espflash") else { return false }
        guard FileManager.default.fileExists(atPath: binPath) else { return false }

        let process = Process()
        process.executableURL = tool
        process.arguments = [
            "write-bin",
            "--baud", "115200",
            "--port", port,
            "0x0", binPath
        ]

        let outPipe = Pipe()
        let errPipe = Pipe()
        process.standardOutput = outPipe
        process.standardError = errPipe

        let outHandle = outPipe.fileHandleForReading
        let errHandle = errPipe.fileHandleForReading
        let accumulator = DataAccumulator()

        outHandle.readabilityHandler = { fh in
            let data = fh.availableData
            if !data.isEmpty {
                Task { await accumulator.append(data) }
                if let chunk = String(data: data, encoding: .utf8), !chunk.isEmpty {
                    print("espflash ⟶", chunk)
                }
            }
        }
        errHandle.readabilityHandler = { fh in
            let data = fh.availableData
            if !data.isEmpty {
                Task { await accumulator.append(data) }
                if let chunk = String(data: data, encoding: .utf8), !chunk.isEmpty {
                    print("espflash (stderr) ⟶", chunk)
                }
            }
        }

        do {
            try process.run()

            let status: Int32 = await withCheckedContinuation { cont in
                process.terminationHandler = { p in
                    outHandle.readabilityHandler = nil
                    errHandle.readabilityHandler = nil
                    try? outHandle.close()
                    try? errHandle.close()
                    cont.resume(returning: p.terminationStatus)
                }
            }

            let collectedData = await accumulator.snapshot()
            let output = String(decoding: collectedData, as: UTF8.self)
            print("espflash output (final)\n", output)
            return status == 0
        } catch {
            outHandle.readabilityHandler = nil
            errHandle.readabilityHandler = nil
            try? outHandle.close()
            try? errHandle.close()

            print("Error on startup: \(error.localizedDescription)")
            return false
        }
    }
}
