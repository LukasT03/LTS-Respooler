import SwiftUI
import AppKit
struct MainFlasherView: View {
    @StateObject private var portMonitor = SerialPortMonitor()
    @State private var board: BoardType = .esp32
    @State private var status: FlashStatus = .idle
    @State private var isFlashing = false
    @State private var progress: Double = 0.0
    @State private var latestFirmwareVersion: String = "-"
    @State private var shouldRefreshLatest = true
    
    var body: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Neuste Firmware Version: \(latestFirmwareVersion)")
                    .fontWeight(.bold)
                Spacer()
            }
            
            HStack {
                Text("Board auswählen:")
                Spacer()
                Picker("", selection: $board) {
                    ForEach(BoardType.allCases) { Text($0.rawValue).tag($0) }
                }
                .pickerStyle(.menu)
                .focusable(false)
            }
            
            Divider()

            HStack {
                VStack(alignment: .leading, spacing: 14) {
                    FlashStepView(title: NSLocalizedString("step_device_found", comment: ""), status: portMonitor.deviceFound ? .success : .failure, detail: AnyView(Text("Port: ") + Text(portMonitor.selectedDevice ?? "–")))
                    FlashStepView(
                        title: NSLocalizedString("step_firmware_downloaded", comment: ""),
                        status: status.downloadIndicator == .idle ? status.flashSuccessIndicator : status.downloadIndicator,
                        detail: AnyView(Text("Datei: ") + Text((status == .downloaded || status == .flashed) ? FirmwareDownloader.lastFilename : "–"))
                    )
                    FlashStepView(
                        title: NSLocalizedString("step_installation_running", comment: ""),
                        status: isFlashing ? .inProgress : status.flashSuccessIndicator,
                        detail: AnyView(
                            Group {
                                if isFlashing {
                                    Text("Fortschritt:")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .overlay(
                                            ProgressView(value: progress)
                                                .progressViewStyle(.linear)
                                                .frame(width: 179, height: 4)
                                                .offset(x: 60, y: 5),
                                            alignment: .topLeading
                                        )
                                } else if status == .flashed {
                                    Text("Fortschritt: fertig!")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                } else {
                                    Text("Fortschritt: –")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        )
                    )
                    FlashStepView(title: NSLocalizedString("step_successful", comment: ""), status: status.flashSuccessIndicator)
                }
                Spacer()
            }

            Spacer()

            HStack {
                if portMonitor.availableDevices.count > 1 {
                    Picker("Port:", selection: $portMonitor.selectedDevice) {
                        ForEach(portMonitor.availableDevices, id: \.self) { port in
                            Text(port).tag(Optional(port))
                        }
                    }
                    .pickerStyle(.menu)
                    .focusable(false)
                }
                Spacer()
                Button(portMonitor.availableDevices.count > 1 ? "Installieren" : "Herunterladen und installieren") {
                    Task {
                        await startFlashing()
                    }
                }
                .padding(.bottom, 2)
                .buttonStyle(.borderedProminent)
                .disabled(!portMonitor.deviceFound || isFlashing)
            }
        }
        .padding (20)
        .task {
            await refreshLatestLoop()
        }
        .onDisappear {
            shouldRefreshLatest = false
        }
    }

    func startFlashing() async {
        status = .downloading
        guard let bin = await FirmwareDownloader.download(for: board) else {
            status = .downloadFailed
            return
        }
        status = .downloaded
        progress = 0.0
        isFlashing = true
        Task {
            let totalDuration: Double = (board == .control3 || board == .control4) ? 12.0 : 96.0
            let interval: Double = 0.5
            var elapsed: Double = 0.0
            while isFlashing && elapsed < totalDuration {
                try? await Task.sleep(nanoseconds: UInt64(interval * 1_000_000_000))
                elapsed += interval
                let fraction = min(elapsed / totalDuration, 1.0)
                await MainActor.run { progress = fraction }
            }
        }
        let success = await ESP32Flasher.flash(binPath: bin, port: portMonitor.selectedDevice!)
        isFlashing = false
        status = success ? .flashed : .flashFailed
        progress = success ? 1.0 : progress
        if !success { progress = 0.0 }
    }
    private func refreshLatestLoop() async {
        await fetchLatestFirmware()
        while shouldRefreshLatest && !Task.isCancelled {
            try? await Task.sleep(nanoseconds: 60 * 1_000_000_000)
            await fetchLatestFirmware()
        }
    }

    @MainActor private func setLatest(_ value: String) {
        latestFirmwareVersion = value.isEmpty ? "-" : value
    }

    private func fetchLatestFirmware() async {
        guard let url = URL(string: "https://download.lts-design.com/Firmware/latest_board_firmware.txt") else {
            await MainActor.run { setLatest("-") }
            return
        }
        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 10
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) {
                let raw = String(data: data, encoding: .utf8) ?? ""
                let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
                await MainActor.run { setLatest(trimmed.isEmpty ? "-" : trimmed) }
            } else {
                await MainActor.run { setLatest("-") }
            }
        } catch {
            await MainActor.run { setLatest("-") }
        }
    }
}
