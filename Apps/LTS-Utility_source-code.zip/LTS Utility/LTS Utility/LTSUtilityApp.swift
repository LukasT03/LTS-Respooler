import SwiftUI
import AppKit

@main
struct LTSUtilityApp: App {
    var body: some Scene {
        Window("LTS Utility", id: "main") {
            MainFlasherView()
                .frame(width: 320, height: 337)
        }
        .windowResizability(.contentSize)
    }
}
